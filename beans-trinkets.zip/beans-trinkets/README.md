# beans.trinkets

A Pen created on CodePen.io. Original URL: [https://codepen.io/Gemma-the-typescripter/pen/JjQXePp](https://codepen.io/Gemma-the-typescripter/pen/JjQXePp).

