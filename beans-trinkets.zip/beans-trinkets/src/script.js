document.addEventListener('DOMContentLoaded', () => {
    const stars = document.querySelectorAll('.star');
    const ratingInput = document.getElementById('rating');

    // Function to handle star click
    stars.forEach(star => {
        star.addEventListener('click', () => {
            const value = star.getAttribute('data-value');
            ratingInput.value = value;
            stars.forEach(s => {
                if (s.getAttribute('data-value') <= value) {
                    s.classList.add('selected');
                } else {
                    s.classList.remove('selected');
                }
            });
        });
    });

    // Function to handle form submission
    document.getElementById('reviewForm').addEventListener('submit', (e) => {
        e.preventDefault();
        
        const reviewText = document.getElementById('reviewText').value;
        const rating = ratingInput.value;

        if (reviewText && rating) {
            const reviewsList = document.getElementById('reviews-list');
            const reviewDiv = document.createElement('div');
            reviewDiv.className = 'review';
            reviewDiv.innerHTML = `<p>${reviewText} - Rating: ${'★'.repeat(rating)}</p>`;
            reviewsList.appendChild(reviewDiv);

            // Clear the form
            document.getElementById('reviewForm').reset();
            ratingInput.value = '0';
            stars.forEach(star => star.classList.remove('selected'));
        }
    });
});
